package com.example.carrinhodecompras.domain.model

data class Produto(
    val id: String,
    val nome: String,
    val preco: Double
)