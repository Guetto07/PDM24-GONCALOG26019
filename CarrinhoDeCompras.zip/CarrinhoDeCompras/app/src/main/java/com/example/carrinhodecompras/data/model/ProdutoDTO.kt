package com.example.carrinhodecompras.data.model

data class ProdutoDTO(
    val id: String,
    val nome: String,
    val preco: Double
)