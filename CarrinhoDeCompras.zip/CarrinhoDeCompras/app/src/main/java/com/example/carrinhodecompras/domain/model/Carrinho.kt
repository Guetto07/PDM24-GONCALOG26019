package com.example.carrinhodecompras.domain.model

data class Carrinho(
    val produtos: List<Produto>
)