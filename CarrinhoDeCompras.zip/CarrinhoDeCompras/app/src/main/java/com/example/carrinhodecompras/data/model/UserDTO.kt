package com.example.carrinhodecompras.data.model

data class UserDTO(
    val id: String,
    val email: String,
    val senha: String
)