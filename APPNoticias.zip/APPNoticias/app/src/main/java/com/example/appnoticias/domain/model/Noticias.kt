package com.example.appnoticias.domain.model

class Noticias(
    val uuid : String,
    val title : String,
    val url : String
)